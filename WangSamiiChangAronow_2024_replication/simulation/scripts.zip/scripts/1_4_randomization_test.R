# simulation results in Wang, Samii, Chang, and Aronow (2024)
rm(list=ls())

##############################################################################
##################If ri package is not installed##############################
##############################################################################
# #ri package no longer available from repository
# install.packages('./simulation/ri_0.9.tar.gz',type='source')


##############################################################################
##################Set Root Directories########################################
##############################################################################
root_dir = "C:/Users/haogechang/OneDrive - Microsoft/Desktop/SpatialReplication/SpatialReplication/"
setwd(root_dir)
data_path="simulation/data_new/"


##############################################################################
##################Import Functions############################################
##############################################################################
source("./simulation/scripts/5_functions_randomization_test.R")
source("./simulation/scripts/6_functions.R")



##############################################################################
#################Today's Date#################################################
##############################################################################
today_date=format(Sys.Date(), format="%b_%d")

# simulation with non-monotonic effect function and YZratio=10
start.time=proc.time()
sim1_raw_data_file = "simulation/data_new/Paired_simData_null_10_May_30_points.RData"
TYPE='null'
YZratio=10
sample_sizes <-c(80, 100, 120)
dVec <- seq(from=.5, to=10, by=.25)
bw <- 1
simulation_result=run_simulation_randomization_test(sim1_raw_data_file,bw,sample_sizes,polygon=0,nperm=1000)
save(simulation_result, file = paste0(data_path,"Paired_randomization_test_", TYPE, "_" ,YZratio,'_',today_date,"_points.RData"))
print(proc.time()-start.time)

# simulation with non-monotonic effect function and YZratio=10
start.time=proc.time()
sim1_raw_data_file = "simulation/data_new/Paired_simData_nonmono_10_May_30_points.RData"
TYPE='nonmono'
YZratio=10
sample_sizes <-c(80, 100, 120)
dVec <- seq(from=.5, to=10, by=.25)
bw <- 1
simulation_result=run_simulation_randomization_test(sim1_raw_data_file,bw,sample_sizes,polygon=0,nperm=1000)
save(simulation_result, file = paste0(data_path,"Paired_randomization_test_", TYPE, "_" ,YZratio,'_',today_date,"_points.RData"))
print(proc.time()-start.time)


# simulation with non-monotonic effect function and YZratio=10
start.time=proc.time()
sim1_raw_data_file = "simulation/data_new/Paired_simData_interactive_10_May_30_points.RData"
TYPE='interactive'
YZratio=10
sample_sizes <-c(80, 100, 120)
dVec <- seq(from=.5, to=10, by=.25)
bw <- 1
simulation_result=run_simulation_randomization_test(sim1_raw_data_file,bw,sample_sizes,polygon=0,nperm=1000)
save(simulation_result, file = paste0(data_path,"Paired_randomization_test_", TYPE, "_" ,YZratio,'_',today_date,"_points.RData"))
print(proc.time()-start.time)
